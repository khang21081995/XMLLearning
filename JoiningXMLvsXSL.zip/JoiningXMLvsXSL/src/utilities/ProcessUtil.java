/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilities;

import java.awt.Desktop;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.IOException;
import java.net.URI;
import java.net.URL;

/**
 *
 * @author khang
 */
public class ProcessUtil {

    public static boolean runProcess(String command) throws IOException, InterruptedException {
//        System.out.println(command);
        Process p = Runtime.getRuntime().exec(command);
        p.waitFor();
        return p.exitValue() == 0;
    }

}
