/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import UI.MainForm;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import utilities.ProcessUtil;

/**
 *
 * @author khang
 */
public class SaxonObject {

    private File xmlFile;
    private File xslFile;
    private String htmlFilePath;

    public String getHtmlFilePath() {
        return htmlFilePath +MainForm.getOSPath()+ getHTMLFileName();
    }

    public void setHtmlFilePath(String htmlFilePath) {
        this.htmlFilePath = htmlFilePath;
    }

    public File getXmlFile() {
        return xmlFile;
    }

    public void setXmlFile(File xmlFile) throws Exception {
        if (xmlFile.getName().toLowerCase().endsWith(".xml")) {
            this.xmlFile = xmlFile;
        } else {
            throw new Exception("Not an XML File");
        }
    }

    public File getXslFile() {
        return xslFile;
    }

    public void setXslFile(File xslFile) throws Exception {
        if (xslFile.getName().toLowerCase().endsWith(".xsl")) {
            this.xslFile = xslFile;
        } else {
            throw new Exception("Not an XSL File");
        }
    }

    public SaxonObject() {
        xmlFile = null;
        xslFile = null;
        htmlFilePath = "";
    }

    public String getHTMLFileName() {
        return xslFile.getName().trim().substring(0, xslFile.getName().length() - 4).toLowerCase() + xmlFile.getName().trim().substring(0, xmlFile.getName().length() - 4).toUpperCase() + ".html";//ten file html

    }

    private String getCommandSaxon() {
        String ret = "";
        if (xmlFile != null && xslFile != null && htmlFilePath != null) {
            ret = "java -jar lib"+MainForm.getOSPath()+"saxon9ee.jar -s:" + xmlFile.getPath() + " -xsl:" + xslFile.getPath() + " -o:" + getHtmlFilePath();
        }
        return ret;
    }

    public boolean compiling() throws IOException, InterruptedException {
        String commandSaxon;
//        System.out.println("1");
        if ((commandSaxon = getCommandSaxon()) == "") {
            return false;
        }
//        System.out.println("2");

        return ProcessUtil.runProcess(commandSaxon);
    }

    //Test
}
